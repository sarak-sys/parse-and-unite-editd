from ._venn import venn, pseudovenn
from ._venn import generate_petal_labels, generate_colors
from ._venn import draw_venn, draw_pseudovenn6
from ._backwards_compatibility import get_labels
from ._backwards_compatibility import venn2, venn3, venn4, venn5, venn6
